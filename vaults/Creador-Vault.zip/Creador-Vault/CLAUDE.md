# Creador Vault — instrucciones para Claude

Este vault es para mis vídeos de TikTok y YouTube.
- Ideas en `Ideas/`, guiones en `Guiones/` (plantilla `Plantillas/Guion.md`).
- Un guion de TikTok dura 30–45 s: gancho en los 2 primeros segundos, 3 puntos, final con pregunta.
- Apunta cada vídeo publicado en [[Publicados]] con fecha y visitas.
- Si una idea funcionó, propón 3 variaciones nuevas en `Ideas/`.
