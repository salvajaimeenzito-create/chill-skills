# {{title}}
**Gancho (0–2 s):** 
1. 
2. 
3. 
**Final:** 
