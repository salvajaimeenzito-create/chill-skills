# Inglés
- [[Asignaturas/Inglés/Past simple]]
