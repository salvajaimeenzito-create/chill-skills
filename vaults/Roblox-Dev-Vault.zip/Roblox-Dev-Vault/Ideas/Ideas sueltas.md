# 💡 Ideas sueltas
- Evento de Halloween con el Kraken zombi → [[Juegos/Kraken Quest/GDD]]
- Mascotas que corren contigo → [[Juegos/Speed Simulator/GDD]]
- Código promocional para TikTok
