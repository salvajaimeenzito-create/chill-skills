# 🎮 Inicio

## Juegos
- [[Juegos/Kraken Quest/GDD|Kraken Quest]]
- [[Juegos/Speed Simulator/GDD|Speed Simulator]]

## Rápido
- 💡 [[Ideas/Ideas sueltas]]
- 🐞 [[Bugs/Lista de bugs]]
- 🚀 [[Updates/v1.0]]
- 🧰 [[Skills que uso]]
