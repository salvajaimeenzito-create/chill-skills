# 🧰 Skills que uso
- LihFolk Stud Voxel → modelos y mascotas
- Bosses Roblox Studs → [[Juegos/Kraken Quest/Boss Kraken]]
- Folk Treadmills → [[Juegos/Speed Simulator/Cintas]]
- Check-UI → [[Juegos/Kraken Quest/Tienda]]
Todas en Chill Skills.
