# Boss Kraken
- Vida: 5000
- Ataques: tentáculo (golpe en área), ola, tinta (ciega 3 s)
- Fase 2 al 50 %: se enfada y ataca el doble de rápido
- Modelo: hecho con la skill **Bosses Roblox Studs**

Vuelve a [[Juegos/Kraken Quest/GDD]]
