# Tienda
| Objeto | Precio | Efecto |
|---|---|---|
| Arpón | 200 conchas | +20 daño |
| Escudo de coral | 500 conchas | -30 % daño recibido |
| Tridente | 1500 conchas | +80 daño |

UI hecha con la skill **Check-UI**. Ver [[Juegos/Kraken Quest/GDD]]
